import rospy
import time
from math import pi
import numpy as np
np.set_printoptions(suppress=True)


from sympy import Function, MatrixSymbol, Matrix, cos, sin, pprint, eye
from sympy import FunctionMatrix, symbols, Lambda, MatPow

import matplotlib.pyplot as plt
from tqdm import tqdm

from robot_params import *
from robot_joint_publisher import *
from utilities import *



class circle_trajectory():

    def __init__(self) -> None:
        
        #Variable to store the Circle Trajectory
        self.TRAJECTORY_POINTS = []

        self.joint_publisher = robot_joint_publisher()

        #As per the DH-frame choice, the inital configuration of the robot can be taken as
        self.q =  [0, -pi/2, pi/2, 0, pi/2, 0]

        #Angular velocity to completer the full circle under 5 seconds
        self.theta_dot = 2*pi/5 

        self.r = 0.3 #radius in meters

        # Resolution of the trajectory is taken as 0.01 radians
        self.detlta_theta = 0.01

        # Time required to move detlta_theta radians at theta_dot velocity
        self.delta_t = (5/(2*pi))*self.detlta_theta

    def make_trajectory(self):
        # Loop ove the 360 degrees to draw the Circle
        for theta in tqdm(np.arange(0, 2*pi , self.detlta_theta)):

            self.joint_publisher.publish_joint(self.q)


            #The projected velocity components of the circle are found as
            # yd =       r * theta_dot * cos(theta)
            # zd =  -1 * r * theta_dot * sin(theta)
            V = np.array( [0, 0, 0, 0, self.r*self.theta_dot*cos(theta) , -1*self.r*self.theta_dot*sin(theta) ], dtype=np.float32)

            #Find the jacobian from the joint angles
            J, T_EF = GetJacobian(self.q, Table_DHParam)

            self.TRAJECTORY_POINTS.append([T_EF[1][3], T_EF[2][3]])

            if theta == 0:
                print(f"Inital Settings at angle {theta} radinas : \n")
                print(f"Joint angles are calculated as : {self.q}\n")
                print("Jacobians is calculated as : ")
                print(J)
                print(f"\nEnd effectory location is calculated as : {self.TRAJECTORY_POINTS}\n")

            #Calculate inverse jacobian
            J_inv = np.linalg.pinv(J)

            #Find the joint velocities
            q_dot = J_inv @ V

            #Integrate the joint angles
            self.q += q_dot * self.delta_t

            time.sleep(self.delta_t)

    def plot_trajectory(self):
        self.figure = plt.figure("Panda Robot tracking a circular trajectory")
        self.ax = self.figure.add_subplot(111)
        self.ax.set_xlabel('Y axis')
        self.ax.set_ylabel('Z axis')
        self.ax.set_aspect(1)

        self.pltTRAJECTORY_POINTS = np.array(self.TRAJECTORY_POINTS)
        self.ax.plot(self.pltTRAJECTORY_POINTS[:,0], self.pltTRAJECTORY_POINTS[:,1])
       
        plt.show()
