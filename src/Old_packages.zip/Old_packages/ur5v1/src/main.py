from circle_trajectory import *

import threading


_trajectory = circle_trajectory()

class thread(threading.Thread):
    Is_Completed= False;
    def __init__(self, thread_name):
        threading.Thread.__init__(self)
        self.thread_name = thread_name


    # helper function to execute the threads
    def run(self):
        _trajectory.make_trajectory()
        self.Is_Completed = True

if __name__ =="__main__":

    rospy.init_node("main_ur5v1")
    op_thread = thread("op_thread")
    op_thread.start()

    rate = rospy.Rate(10)

    while not rospy.is_shutdown():

        if op_thread.Is_Completed:
            _trajectory.plot_trajectory()
            op_thread.Is_Completed = False
        rate.sleep()

    